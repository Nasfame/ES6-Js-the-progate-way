class Animal {
}

// Assign the Animal class instance to the animal constant
const animal = new Animal();
console.log(animal);

// Output the value of the animal constant

