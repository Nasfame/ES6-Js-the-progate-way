class Animal {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }
  
  greet() {
    console.log("Hello");
  
  }
  info(){
    console.log(`My name is ${this.name}`);
    console.log(`I'm ${this.age} years old`);
  }
  // Add the info method
  
  
}

const animal = new Animal("Leo", 3);
animal.greet();
animal.info();
// Call the info method using the animal constant

