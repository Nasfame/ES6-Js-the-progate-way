const half = (number) => {
  // Return the the value of the number variable divided by 2
  return number/2;
};

// Define the result constant
const result = half(130);

// Print the message "Half of 130 is ____"

console.log("Half of 130 is"+result);