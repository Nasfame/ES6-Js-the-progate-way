// Add a name argument to the function
const greet = (name) => {
  // Print the message "Hello, ____"
  console.log("Hello,"+name);
};

// Call the greet function with "Master White" as an argument
greet('Master White');
