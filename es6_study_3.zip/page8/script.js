// Define the name constant
const name = "Ken the Ninja";

const introduce = (name) => {
  // Print "I am ____" in the console
  console.log("I am "+ name);
  
};

// Call the introduce function
introduce('Master White');

// Print the value of the name constant
console.log(name);
