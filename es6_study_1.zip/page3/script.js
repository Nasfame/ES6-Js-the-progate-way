// Output the result of 5 plus 3
console.log(5+3);

// Output the result of 20 minus 8
console.log(20-8);


// Output the string "4 + 5"
console.log("4 + 5");

