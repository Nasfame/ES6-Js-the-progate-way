const age = 24;

// Output the result of age >= 18
console.log(age >= 18);

// Output the result of age < 18
console.log(age < 18);

// When the value of age is 18 or higher, output "I am 18 or older"
if (age >= 18) {
  console.log("I am 18 or older");
}
