// Declare the name variable with the string value "Ken the Ninja"
let name = "Ken the Ninja";

// Output the value of the name variable
console.log(name);
