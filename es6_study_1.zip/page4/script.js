// Output the result of 8 times 4

console.log(8*4);

// Output the result of 24 divided by 4
console.log(24/4);


// Output the remainder after dividing 7 by 2

console.log(7%2);
