// Declare the language constant
const language="French";

// Output the value of the language constant
console.log(language);

// Use the language constant to output "I can speak ____"

console.log("I can speak"+language);