const age = 17;

// When age is over 10 or more but less than 18, output:
// "I am under 18 but over 9 years old"
if (age >= 18) {
  console.log("I am 18 or older");
} 
else if(age>=10){
  console.log("I am under 18 but over 9 years old");
}
 else {
  console.log("I am under 10 years old");
}
