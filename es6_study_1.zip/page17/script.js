const age = 24;

// Add an if statement with the specified conditions
if(age>=20 && age<30){
  console.log("I am in my 20s");
}
