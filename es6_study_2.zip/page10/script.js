// Declare the character constant and assign the provided object to it
const character={name:"Ken the Ninja",age:14};
console.log(character);

// Print the value of character

