// Declare the number variable
let number=1;


// Add a while loop here

while(number<=100){
  console.log(number);
  number+=1;
}