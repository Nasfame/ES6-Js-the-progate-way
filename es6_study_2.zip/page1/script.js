// Declare the number variable
let number=1;

// Print the value of the number variable, then add 1 to it
console.log(number);
number+=1;


// Copy the 2 lines above and paste them 4 times below
console.log(number);
number+=1;
console.log(number);
number+=1;
console.log(number);
number+=1;
console.log(number);
number+=1;
