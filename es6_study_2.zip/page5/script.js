// Assign the provided array to the animals constant
const animals = ["dog","cat","sheep"];

// Print the animals constant

console.log(animals);
